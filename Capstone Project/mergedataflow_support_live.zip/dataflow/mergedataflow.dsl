source(output(
		distance as string,
		cab_type as string,
		time_stamp as string,
		destination as string,
		source as string,
		price as string,
		surge_multiplier as string,
		id as string,
		product_id as string,
		name as string
	),
	allowSchemaDrift: true,
	validateSchema: false,
	isolationLevel: 'READ_UNCOMMITTED',
	format: 'table',
	partitionBy('hash', 1)) ~> lyftSQLTablesource
source(output(
		distance as string,
		cab_type as string,
		time_stamp as string,
		destination as string,
		source as string,
		price as string,
		surge_multiplier as string,
		id as string,
		product_id as string,
		name as string
	),
	allowSchemaDrift: true,
	validateSchema: false,
	ignoreNoFilesFound: false,
	partitionBy('hash', 1)) ~> uberblobstorage
lyftSQLTablesource, uberblobstorage union(byName: true)~> union
union sink(allowSchemaDrift: true,
	validateSchema: false,
	deletable:false,
	insertable:true,
	updateable:false,
	upsertable:true,
	format: 'document',
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true,
	partitionBy('hash', 1)) ~> cosmossink