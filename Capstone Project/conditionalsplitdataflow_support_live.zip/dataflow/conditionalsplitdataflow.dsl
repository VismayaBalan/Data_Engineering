source(output(
		distance as string,
		cab_type as string,
		time_stamp as string,
		destination as string,
		source as string,
		price as string,
		surge_multiplier as string,
		id as string,
		product_id as string,
		name as string
	),
	allowSchemaDrift: true,
	validateSchema: false,
	ignoreNoFilesFound: false,
	partitionBy('hash', 1)) ~> blobsource
source(output(
		distance as string,
		cab_type as string,
		time_stamp as string,
		destination as string,
		source as string,
		price as string,
		surge_multiplier as string,
		id as string,
		product_id as string,
		name as string
	),
	allowSchemaDrift: true,
	validateSchema: false,
	ignoreNoFilesFound: false,
	partitionBy('hash', 1)) ~> blobsource2
blobsource split(cab_type == 'Uber',
	disjoint: false) ~> uberdatasplit@(UberRides)
blobsource2 split(cab_type == 'Lyft',
	disjoint: false) ~> lyftsplit@(lyftRides)
uberdatasplit@UberRides sink(allowSchemaDrift: true,
	validateSchema: false,
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true,
	partitionBy('hash', 1)) ~> uberRides
lyftsplit@lyftRides sink(allowSchemaDrift: true,
	validateSchema: false,
	deletable:false,
	insertable:true,
	updateable:false,
	upsertable:false,
	format: 'table',
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true,
	errorHandlingOption: 'stopOnFirstError') ~> lyftTable